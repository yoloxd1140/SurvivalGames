<?php

namespace sg\sw;

use pocketmine\block\Block;
use pocketmine\item\Item;
use pocketmine\level\Position;
use pocketmine\level\sound\{PopSound, ClickSound, EndermanTeleportSound, Sound, BlazeShootSound};
use pocketmine\Player;
use pocketmine\tile\Chest;
use pocketmine\utils\{Config, TextFormat};
use pocketmine\item\enchantment\{Enchantment, EnchantmentInstance};
use Scoreboards\Scoreboards;
use sg\sw\SWmain;

class SWarena {

    //Player states
    const PLAYER_NOT_FOUND = 0;
    const PLAYER_PLAYING = 1;
    const PLAYER_SPECTATING = 2;

    //Game states
    const STATE_COUNTDOWN = 0;
    const STATE_RUNNING = 1;
    const STATE_NOPVP = 2;

    /** @var PlayerSnapshot[] */
    private $playerSnapshots = [];//store player's inventory, health etc pre-match so they don't lose it once the match ends

    /** @var int */
    public $GAME_STATE = SWarena::STATE_COUNTDOWN;

    /** @var SWmain */
    private $plugin;

    /** @var string */
    private $SWname;

    /** @var int */
    private $slot;

    /** @var string */
    private $world;

    /** @var int */
    private $countdown = 60;//Seconds to wait before the game starts

    /** @var int */
    private $maxtime = 300;//Max seconds after the countdown, if go over this, the game will finish

    private $gametime = 420;
    /** @var int */
    public $void = 0;//This is used to check "fake void" to avoid fall (stunck in air) bug

    /** @var array */
    private $spawns = [];//Players spawns

    /** @var int */
    private $time = 0;//Seconds from the last reload | GAME_STATE

    /** @var string[] */
    private $players = [];//[rawUUID] => int(player state)

    /** @var array[] */
    private $playerSpawns = [];

    /**
     * @param SWmain $plugin
     * @param string $SWname
     * @param int $slot
     * @param string $world
     * @param int $countdown
     * @param int $maxtime
     * @param int $void
     */
    public function __construct(SWmain $plugin, string $SWname = "duel", int $slot = 0, string $world = "world", int $countdown = 60, int $maxtime = 300, int $void = 0)
    {
        $this->gametime = 420;
        $this->plugin = $plugin;
        $this->SWname = $SWname;
        $this->slot = ($slot + 0);
        $this->world = $world;
        $this->countdown = ($countdown + 0);
        $this->maxtime = ($maxtime + 0);
        $this->void = $void;

        if (!$this->reload($error)) {
            $logger = $this->plugin->getLogger();
            $logger->error("An error occured while reloading the arena: " . TextFormat::YELLOW . $this->SWname);
            $logger->error($error);
            $this->plugin->getServer()->getPluginManager()->disablePlugin($this->plugin);
        }
    }

    final public function getName() : string
    {
        return $this->SWname;
    }

    /**
     * @return bool
     */
    private function reload(&$error = null) : bool
    {
        //Map reset
        if (!is_file($file = $this->plugin->getDataFolder() . "arenas/" . $this->SWname . "/" . $this->world . ".tar") && !is_file($file = $this->plugin->getDataFolder() . "arenas/" . $this->SWname . "/" . $this->world . ".tar.gz")) {
            $error = "Cannot find world backup file $file";
            return false;
        }

        $server = $this->plugin->getServer();

        if ($server->isLevelLoaded($this->world)) {
            $server->unloadLevel($server->getLevelByName($this->world));
        }

        if ($this->plugin->configs["world.reset.from.tar"]) {
            $tar = new \PharData($file);
            $tar->extractTo($server->getDataPath() . "worlds/" . $this->world, null, true);
        }

        $server->loadLevel($this->world);
        $server->getLevelByName($this->world)->setAutoSave(false);

        $config = new Config($this->plugin->getDataFolder() . "arenas/" . $this->SWname . "/settings.yml", Config::YAML, [//TODO: put descriptions
            "name" => $this->SWname,
            "slot" => $this->slot,
            "world" => $this->world,
            "countdown" => $this->countdown,
            "maxGameTime" => $this->maxtime,
            "void_Y" => $this->void,
            "spawns" => []
        ]);

        $this->SWname = $config->get("name");
        $this->slot = (int) $config->get("slot");
        $this->world = $config->get("world");
        $this->countdown = (int) $config->get("countdown");
        $this->maxtime = (int) $config->get("maxGameTime");
        $this->spawns = $config->get("spawns");
        $this->void = (int) $config->get("void_Y");

        $this->players = [];
        $this->time = 0;
        $this->GAME_STATE = SWarena::STATE_COUNTDOWN;

        //Reset Sign
        $this->plugin->refreshSigns($this->SWname, 0, $this->slot);
        return true;
    }

    public function getState() : string
    {
        if ($this->GAME_STATE !== SWarena::STATE_COUNTDOWN || count(array_keys($this->players, SWarena::PLAYER_PLAYING, true)) >= $this->slot) {
            return TextFormat::RED . TextFormat::BOLD . "Running";
        }

        return TextFormat::WHITE . "Tap to join";
    }

    public function getSlot(bool $players = false) : int
    {
        return $players ? count($this->players) : $this->slot;
    }

    public function getWorld() : string
    {
        return $this->world;
    }

    /**
     * @param Player $player
     * @return int
     */
    public function inArena(Player $player) : int
    {
        return $this->players[$player->getRawUniqueId()] ?? SWarena::PLAYER_NOT_FOUND;
    }

    public function setPlayerState(Player $player, ?int $state) : void
    {
        if ($state === null || $state === SWarena::PLAYER_NOT_FOUND) {
            unset($this->players[$player->getRawUniqueId()]);
            return;
        }

        $this->players[$player->getRawUniqueId()] = $state;
    }

    /**
     * @param Player $player
     * @param int $slot
     * @return bool
     */
    public function setSpawn(Player $player, int $slot = 1) : bool
    {
        if ($slot > $this->slot) {
            $player->sendMessage(TextFormat::RED . "This arena have only got " . TextFormat::WHITE . $this->slot . TextFormat::RED . " slots");
            return false;
        }

        $config = new Config($this->plugin->getDataFolder() . "arenas/" . $this->SWname . "/settings.yml", Config::YAML);

        if (empty($config->get("spawns", []))) {
            $config->set("spawns", array_fill(1, $this->slot, [
                "x" => "n.a",
                "y" => "n.a",
                "z" => "n.a",
                "yaw" => "n.a",
                "pitch" => "n.a"
            ]));
        }
        $s = $config->get("spawns");
        $s[$slot] = [
            "x" => floor($player->x),
            "y" => floor($player->y),
            "z" => floor($player->z),
            "yaw" => $player->yaw,
            "pitch" => $player->pitch
        ];

        $config->set("spawns", $s);
        $this->spawns = $s;

        if (!$config->save() || count($this->spawns) !== $this->slot) {
            $player->sendMessage(TextFormat::RED . "An error occured setting the spawn, please contact the developer.");
            return false;
        }

        return true;
    }

    /**
     * @return bool
     */
    public function checkSpawns() : bool
    {
        if (empty($this->spawns)) {
            return false;
        }

        foreach ($this->spawns as $key => $val) {
            if (!is_array($val) || count($val) !== 5 || $this->slot !== count($this->spawns) || in_array("n.a", $val, true)) {
                return false;
            }
        }
        return true;
    }

    public function Enchant(int $enchantment, int $level): EnchantmentInstance{
        return new EnchantmentInstance(Enchantment::getEnchantment($enchantment), $level);
    }

    private function refillChests() : void {
        $contents = $this->plugin->getChestContents();
        foreach($this->plugin->getServer()->getLevelByName($this->world)->getTiles() as $tile){
            if($tile instanceof Chest){
                $inventory = $tile->getInventory();
                $inventory->clearAll(false);
                if(empty($contents)){
                    $contents = $this->plugin->getChestContents();
                }
                foreach(array_shift($contents) as $key => $val){
                    $inventory->setItem($key, Item::get($val[0], 0, $val[1]), false);
                    $item = Item::get($val[0], 0, $val[1]);
					if(mt_rand(1, 100) <= 2){
                        $potion = Item::get(438, 16, 1);
                        $tile->getInventory()->setItem(mt_rand(1, 25), $potion);
                    }
					if(mt_rand(1, 100) <= 21){
                        $potion = Item::get(373, 13, 1);
                        $tile->getInventory()->setItem(mt_rand(1, 25), $potion);
                    }
					if(mt_rand(1, 100) <= 1){
                        $potion = Item::get(373, 28, 1);
                        $tile->getInventory()->setItem(mt_rand(1, 25), $potion);
                    }
                    if(rand(1, 100) <= 10){
                        if($item instanceof \pocketmine\item\Sword){
                            $item->addEnchantment($this->Enchant(9, 2));
                            $item->addEnchantment($this->Enchant(12, 2));
                        }
                        elseif($item instanceof \pocketmine\item\Armor){
                            $item->addEnchantment($this->Enchant(0, 2));
                        }
                        elseif($item instanceof \pocketmine\item\Bow){
                            $item->addEnchantment($this->Enchant(19, 2));
                            $item->setCount(1);
                        }
                    }
                }
                $inventory->sendContents($inventory->getViewers());
            }
        }
    }

    public function tick() : void
    {
        $config = $this->plugin->configs;

        switch ($this->GAME_STATE) {
            case SWarena::STATE_COUNTDOWN:
                $player_cnt = count($this->players);

                if ($player_cnt < $config["needed.players.to.run.countdown"]) {
                	foreach ($this->getPlayers() as $p) {
                        $api = Scoreboards::getInstance();
                        $api->new($p, "SkyWars1", "§l§eSurvivalGames");
                        $api->setLine($p, 1, " ");
                        $api->setLine($p, 2, "§fMap: §a{$this->SWname}");
                        $api->setLine($p, 3, "§fPlayers Left: §a". $this->getSlot(true));
                        $api->setLine($p, 4, "  ");
                        $api->setLine($p, 5, "§fWaiting...");
                        $api->setLine($p, 6, "   ");
                        $api->setLine($p, 7, "§fMode: §aSolo");
                        $api->setLine($p, 8, "      ");
                        $api->setLine($p, 9, "§eXvEnOm");
                        $api->getObjectiveName($p);
                    }
                    return;
                }
                if (($config["start.when.full"] && $this->slot <= $player_cnt) || $this->time >= $this->countdown) {
                    $this->start();
                    return;
                }
                if ($this->time % 30 === 0) {
                    $this->sendMessage(str_replace("{N}", date("i:s", ($this->countdown - $this->time)), $this->plugin->lang["chat.countdown"]));
                }
                
            foreach ($this->plugin->getServer()->getLevelByName($this->world)->getPlayers() as $p) {
            	$api = Scoreboards::getInstance();
                    $api->new($p, "SkyWars1", "§l§eSurvivalGames");
                    $api->setLine($p, 1, " ");
                    $api->setLine($p, 2, "§fStart in: §a".date("i:s", ($this->countdown - $this->time)));
                    $api->setLine($p, 3, "  ");
                    $api->setLine($p, 4, "§fPlayers left: §a".$this->getSlot(true));
                    $api->setLine($p, 5, "    ");
                    $api->setLine($p, 6, "§fStarting...");
                    $api->setLine($p, 7, "     ");
                    $api->setLine($p, 8, "§fMap: §a{$this->SWname}");
                    $api->setLine($p, 9, "§fMode: §aNormal");
                    $api->setLine($p, 10, "      ");
                    $api->setLine($p, 11, "§eXvEnOm");
                    $api->getObjectiveName($p);
                }
                if ($this->countdown - $this->time === 10) {
                    foreach ($this->getPlayers() as $player) {
                        $player->getLevel()->addSound(new PopSound($player), [$player]);
                        $player->sendPopup("§eStart In > §a■■■■■■■■■■ §a10");
                    }
                }
                if ($this->countdown - $this->time === 9) {
                    foreach ($this->getPlayers() as $player) {
                        $player->getLevel()->addSound(new PopSound($player), [$player]);
                        $player->sendPopup("§eStart In > §a■■■■■■■■■§r■ §a9");
                    }
                }
                if ($this->countdown - $this->time === 8) {
                    foreach ($this->getPlayers() as $player) {
                        $player->getLevel()->addSound(new PopSound($player), [$player]);
                        $player->sendPopup("§eStart In > §a■■■■■■■■§r■■ §a8");
                    }
                }
                if ($this->countdown - $this->time === 7) {
                    foreach ($this->getPlayers() as $player) {
                        $player->getLevel()->addSound(new PopSound($player), [$player]);
                        $player->sendPopup("§eStart In > §a■■■■■■■§r■■■ §a7");
                    }
                }
                if ($this->countdown - $this->time === 6) {
                    foreach ($this->getPlayers() as $player) {
                        $player->getLevel()->addSound(new PopSound($player), [$player]);
                        $player->sendPopup("§eStart In > §a■■■■■■§r■■■■ §a6");
                    }
                }
                if ($this->countdown - $this->time === 5) {
                    foreach ($this->getPlayers() as $player) {
                        $player->getLevel()->addSound(new PopSound($player), [$player]);
                        $player->sendPopup("§eStart In > §a■■■■■§r■■■■■ §a5");
                    }
                }
                if ($this->countdown - $this->time === 4) {
                    foreach ($this->getPlayers() as $player) {
                    	$player->getLevel()->addSound(new PopSound($player), [$player]);
                        $player->sendPopup("§eStart In > §a■■■■§r■■■■■■ §a4");
                    }
                }
                if ($this->countdown - $this->time === 3) {
                    foreach ($this->getPlayers() as $player) {
                        $player->getLevel()->addSound(new ClickSound($player), [$player]);
                        $player->sendPopup("§eStart In > §c■■■§r■■■■■■■ §a3");
                    }
                }
                if ($this->countdown - $this->time === 2) {
                    foreach ($this->getPlayers() as $player) {
                        $player->getLevel()->addSound(new ClickSound($player), [$player]);
                        $player->sendPopup("§eStart In > §c■■§r■■■■■■■■ §a2");
                    }
                }
                if ($this->countdown - $this->time === 1) {
                    foreach ($this->getPlayers() as $player) {
                        $player->getLevel()->addSound(new ClickSound($player), [$player]);
                        $player->sendPopup("§eStart In > §c■§r■■■■■■■■■ §a1");
                        $player->sendMessage("§eYou Have 4 Second For Looting...");
                    }
                }
                if ($this->countdown - $this->time === 0) {
                    foreach ($this->getPlayers() as $player) {
                        $player->sendMessage("§eYou Have 4 Second For Looting...");
                    }
                }
          
                //$this->sendPopup(str_replace("{N}", date("i:s", ($this->countdown - $this->time)), $this->plugin->lang["popup.countdown"]));
                break;
            case SWarena::STATE_RUNNING:
                $player_cnt = count(array_keys($this->players, SWarena::PLAYER_PLAYING, true));
                if ($player_cnt < 2 || $this->time >= $this->maxtime) {
                    $this->stop();
                    return;
                }
                
                foreach ($this->getPlayers() as $p) {
                    $api = Scoreboards::getInstance();
                    $api->new($p, "SkyWars1", "§l§eSurvivalGames");
                    $api->setLine($p, 1, " ");
                    $api->setLine($p, 2, "§fEnds in: §a".date("i:s", ($this->maxtime - $this->time)));
                    $api->setLine($p, 3, "  ");
                    $api->setLine($p, 4, "§fPlayers left: §a".$this->getSlot(true));
                    $api->setLine($p, 5, "    ");
                    $api->setLine($p, 6, "§fFight!");
                    $api->setLine($p, 7, "     ");
                    $api->setLine($p, 8, "§fMap: §a{$this->SWname}");
                    $api->setLine($p, 9, "§fMode: §aNormal");
                    $api->setLine($p, 10, "      ");
                    $api->setLine($p, 11, "§eXvEnOm");
                    $api->getObjectiveName($p);
                }

                if($this->GAME_STATE > SWarena::STATE_COUNTDOWN){
                	$derecha = str_repeat(" ", 80);
                    $derechano = str_repeat(" ", 85);
	 	 	 	 $arriba = str_repeat("\n", 14);
                    $this->gametime--;
                    $m = floor($this->gametime / 60);
                    $s = $this->gametime % 60;
                    $time = ($m < 10 ? "0" : "") . $m . ":" . ($s < 10 ? "0" : "") . $s;
                    $alive = count($this->players);
                }

                if ($config["chest.refill"] && ($this->time % $config["chest.refill.rate"] === 0)) {
                    $this->sendMessage($this->plugin->lang["game.chest.refill"]);
                }
                break;
            case SWarena::STATE_NOPVP:
                if ($this->time <= $config["no.pvp.countdown"]) {
                    //$this->sendPopup(str_replace("{COUNT}", $config["no.pvp.countdown"] - $this->time + 1, $this->plugin->lang["no.pvp.countdown"]));
                    foreach ($this->getPlayers() as $p) {
                        $api = Scoreboards::getInstance();
                        $api->new($p, "SkyWars1", "§l§eSurvivalGames");
                        $api->setLine($p, 1, " ");
                        $api->setLine($p, 2, "§fPvP Enable: §a".date("i:s", ($config["no.pvp.countdown"] - $this->time)));
                        $api->setLine($p, 3, "  ");
                        $api->setLine($p, 4, "§fPlayers left: §a".$this->getSlot(true));
                        $api->setLine($p, 5, "    ");
                        $api->setLine($p, 6, "§fLooting...");
                        $api->setLine($p, 7, "     ");
                        $api->setLine($p, 8, "§fMap: §a{$this->SWname}");
                        $api->setLine($p, 9, "§fMode: §aNormal");
                        $api->setLine($p, 10, "      ");
                        $api->setLine($p, 11, "§eXvEnOm");
                        $api->getObjectiveName($p);
                    }
                } else {
                    $this->GAME_STATE = SWarena::STATE_RUNNING;
                }
                break;
        }

        ++$this->time;
    }

    public function join(Player $player, bool $sendErrorMessage = true) : bool
    {
        if ($this->GAME_STATE !== SWarena::STATE_COUNTDOWN) {
            if ($sendErrorMessage) {
                $player->sendMessage($this->plugin->lang["sign.game.running"]);
            }
            return false;
        }

        if (count($this->players) >= $this->slot || empty($this->spawns)) {
            if ($sendErrorMessage) {
                $player->sendMessage($this->plugin->lang["sign.game.full"]);
            }
            return false;
        }

        //Sound
        $player->getLevel()->addSound(new EndermanTeleportSound($player), [$player]);

        //Removes player things
        $player->setGamemode(2);
        $player->getServer()->dispatchCommand($player, "sh off");
        $this->playerSnapshots[$player->getId()] = new PlayerSnapshot($player, $this->plugin->configs["clear.inventory.on.arena.join"], $this->plugin->configs["clear.effects.on.arena.join"]);
        $player->setMaxHealth($this->plugin->configs["join.max.health"]);

        if ($player->getAttributeMap() != null) {//just to be really sure
            if (($health = $this->plugin->configs["join.health"]) > $player->getMaxHealth() || $health < 1) {
                $health = $player->getMaxHealth();
            }
            $player->setHealth($health);
            $player->setFood(20);
        }

        $player->getInventory()->clearAll();
        $player->getArmorInventory()->clearAll();
		$player->getInventory()->setItem(7, Item::get(Item::STICK)->setCustomName("§cQuit lobby"));
        $server = $this->plugin->getServer();
        $server->loadLevel($this->world);
        $level = $server->getLevelByName($this->world);

        $tmp = array_shift($this->spawns);
        $player->teleport(new Position($tmp["x"] + 0.5, $tmp["y"], $tmp["z"] + 0.5, $level), $tmp["yaw"], $tmp["pitch"]);
        $this->playerSpawns[$player->getRawUniqueId()] = $tmp;

        $this->setPlayerState($player, SWarena::PLAYER_PLAYING);
        $this->plugin->setPlayerArena($player, $this->getName());
        $player->setImmobile(true);
        
        $this->sendMessage(str_replace("{COUNT}", "[" . $this->getSlot(true) . "/" . $this->slot . "]", str_replace("{PLAYER}", $player->getNameTag(), $this->plugin->lang["game.join"])));
        $this->plugin->refreshSigns($this->SWname, $this->getSlot(true), $this->slot, $this->getState());
        return true;
    }

    public function getPlayers(?int $player_state = null) : array
    {
        return array_intersect_key($this->plugin->getServer()->getOnlinePlayers(), $player_state === null ? $this->players : array_intersect($this->players, [$player_state]));
    }
    public function sendMessage(string $message) : void
    {
        $this->plugin->getServer()->broadcastMessage($message, $this->getPlayers());
    }
    public function sendPopup(string $message) : void
    {
        $this->plugin->getServer()->broadcastPopup($message, $this->getPlayers());
    }
    public function sendSound(string $sound_class) : void
    {
        if (!is_subclass_of($sound_class, Sound::class, true)) {
            throw new \InvalidArgumentException($sound_class . " must be an instance of " . Sound::class);
        }
        foreach ($this->getPlayers() as $player) {
            $player->getLevel()->addSound(new $sound_class($player), [$player]);
        }
    }

    /**
     * @param Player $player
     * @param bool $left
     * @param bool $spectate
     * @return bool
     */
    private function quit(Player $player, bool $left = false, bool $spectate = false) : bool
    {
        $current_state = $this->inArena($player);
        if ($current_state === SWarena::PLAYER_NOT_FOUND) {
            return false;
        }

        $this->setPlayerState($player, null);

        if ($this->GAME_STATE === SWarena::STATE_COUNTDOWN) {
            $player->setImmobile(false);
            $this->spawns[] = $this->playerSpawns[$uuid = $player->getRawUniqueId()];
            unset($this->playerSpawns[$uuid]);
        }

        if ($current_state === SWarena::PLAYER_SPECTATING) {
            foreach ($this->getPlayers() as $pl) {
                $pl->showPlayer($player);
            }

            $this->setPlayerState($player, null);
            return true;
        }

        $this->plugin->setPlayerArena($player, null);
        $this->plugin->refreshSigns($this->SWname, $this->getSlot(true), $this->slot, $this->getState());

        if ($left) {
            $this->sendMessage(str_replace("{COUNT}", "[" . $this->getSlot(true) . "/" . $this->slot . "]", str_replace("{PLAYER}", $player->getDisplayName(), $this->plugin->lang["game.left"])));
        }

        if ($spectate && $current_state !== SWarena::PLAYER_SPECTATING) {
            $this->setPlayerState($player, SWarena::PLAYER_SPECTATING);
            foreach ($this->getPlayers(SWarena::PLAYER_SPECTATING) as $pl) {
                $pl->showPlayer($player);
            }
        }
        return true;
    }

    /**
     * @param Player $p
     * @param bool $left
     * @param bool $spectate
     * @return bool
     */
    public function closePlayer(Player $player, bool $left = false, bool $spectate = false) : bool
    {
        if ($this->quit($player, $left, $spectate)) {
            $player->setGamemode($player->getServer()->getDefaultGamemode());
            if (!$spectate) {
            	$api = Scoreboards::getInstance();
                $api->remove($player);
                $player->getServer()->dispatchCommand($player, "sh on");
                $player->teleport($player->getServer()->getDefaultLevel()->getSpawnLocation());
                $playerSnapshot = $this->playerSnapshots[$player->getId()];
                unset($this->playerSnapshots[$player->getId()]);
                $playerSnapshot->injectInto($player);
            } elseif ($this->GAME_STATE !== SWarena::STATE_COUNTDOWN && 1 < count(array_keys($this->players, SWarena::PLAYER_PLAYING, true))) {
                $player->setGamemode(Player::SPECTATOR);
                foreach ($this->getPlayers() as $pl) {
                    $pl->hidePlayer($player);
                }

                $idmeta = explode(":", $this->plugin->configs["spectator.quit.item"]);
                $inventory = $player->getInventory();
                $inventory->clearAll();
                $inventory->setHeldItemIndex(0);
                $inventory->setItemInHand(Item::get((int)$idmeta[0], (int)$idmeta[1], 1));
                $inventory->setHeldItemIndex(1);
            }
            return true;
        }
        return false;
    }

    private function start() : void
    {
        if ($this->plugin->configs["chest.refill"]) {
            $this->refillChests();
        }
        

        foreach ($this->getPlayers() as $player) {
            $player->setMaxHealth($this->plugin->configs["join.max.health"]);
            $player->setMaxHealth($player->getMaxHealth());
            $player->getInventory()->clearAll();
            $player->getArmorInventory()->clearAll();
            if ($player->getAttributeMap() !== null) {//just to be really sure
                if (($health = $this->plugin->configs["join.health"]) > $player->getMaxHealth() || $health < 1) {
                    $health = $player->getMaxHealth();
                }
                $player->setHealth($health);
                $player->setFood(20);
                $player->setScale(1);
            }
                $kit = rand(1,1);
                switch($kit){
                    case 1:
                
                $helm = Item::get(000);
                $chest = Item::get(299);
                $legs = Item::get(000);
                $boots = Item::get(000);

                $player->getArmorInventory()->setHelmet($helm);
                $player->getArmorInventory()->setChestplate($chest);
                $player->getArmorInventory()->setLeggings($legs);
                $player->getArmorInventory()->setBoots($boots);
                $player->getArmorInventory()->sendContents($player);
                $player->getInventory()->addItem(Item::get(35, 0, 0));
                $player->getInventory()->addItem(Item::get(35, 0, 0));
                $player->getInventory()->addItem(Item::get(35, 0, 0));
                $player->getInventory()->addItem(Item::get(35, 0, 0));
                $player->getInventory()->setItem(4, Item::get(35, 0, 0)->setCustomName("§cSNOW"));
                $player->getInventory()->setItem(5, Item::get(35, 0, 0)->setCustomName("§cWOOD"));
                $player->getInventory()->setItem(6, Item::get(466, 0, 0)->setCustomName("§cWOOD"));
                $player->getInventory()->sendContents($player);                  
                    break;
            }

            $player->addTitle("§l§o§eSurvivalGames");
            $player->setFlying(false);
            $player->setGamemode(0);

            $level = $player->getLevel();
            $pos = $player->floor();

            for ($i = 1; $i <= 2; ++$i) {
                if ($level->getBlockIdAt($pos->x, $pos->y - $i, $pos->z) === Block::GLASS) {
                    $level->setBlock($pos->subtract(0, $i, 0), Block::get(Block::AIR), false);
                }
            }

            $player->setImmobile(false);
        }

        $this->time = 0;
        $this->gametime = 420;
        $this->GAME_STATE = SWarena::STATE_NOPVP;
        $this->plugin->refreshSigns($this->SWname, $this->getSlot(true), $this->slot, $this->getState());
    }

    public function stop(bool $force = false) : bool
    {
        $server = $this->plugin->getServer();
        $server->loadLevel($this->world);
        $this->gametime = 420;

        foreach ($this->getPlayers() as $player) {
            $is_winner = !$force && $this->inArena($player) === SWarena::PLAYER_PLAYING;
            $this->closePlayer($player);

            if ($is_winner) {
                //Broadcast winner
                $server->broadcastMessage(str_replace(["{SWNAME}", "{PLAYER}"], [$this->SWname, $player->getName()], $this->plugin->lang["server.broadcast.winner"]), $server->getDefaultLevel()->getPlayers());
                $player->addTitle("§aYou Win", "§7You Survive", 10, 30, 10);
                $name = $player->getName();
                $data = new Config($this->plugin->getDataFolder() . "topsg.yml", Config::YAML);
                $up = $data->get($name);
				$data->set($name, $up + 1);
				$data->save();
                
            }
        }

        $this->reload();
        return true;
    }
}